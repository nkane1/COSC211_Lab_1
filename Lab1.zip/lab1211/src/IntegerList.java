/**
 * IntegerList.java
 *
 * Define an IntegerList class with methods to create, fill, sort, and search in
 * a list of integers.
 * 
 */

import java.util.Scanner;
public class IntegerList {

	int[] list; // values in the list
	int[] temp;
	int used;
	Scanner kb=new Scanner(System.in);

	/**
	 * Constructor
	 *
	 * Create a list of the given size
	 * 
	 * @param size
	 *            size of the list
	 */

	public IntegerList(int size) {
		list = new int[size];
	}
	
	/**
	 * Copy Constructor
	 * 
	 * Creates a copy of the argument
	 * 
	 * @param oldIntegerList
	 */
	public IntegerList(IntegerList oldIntegerList){
		list=oldIntegerList.list;
	}

	/**
	 * Fill array with integers between 1 and 100, inclusive
	 */

	public void randomize() {
		for (int i = 0; i < list.length; i++)
			list[i] = (int) (Math.random() * 20) + 1;

		used = list.length;
	}

	/**
	 * Doubles the size of the array list.
	 */
	public void increaseSize() {
		temp = new int[list.length];
		for (int i = 0; i < list.length; i++)
			temp[i] = list[i];
		list = new int[(list.length) * 2];
		for (int i = 0; i < temp.length; i++)
			list[i] = temp[i];
	}

	/**
	 * Adds a new element to the next unused position in the array.
	 * 
	 * @param newVal the value to be added
	 */
	public void addElement(int newVal) {
		if (used == list.length) {
			increaseSize();
		}
		list[used] = newVal;
		used++;
	}
	/**
	 * Removes the last instance of a given element in the array.
	 * 
	 * @param newVal the value to be removed
	 */
	public void removeLast(int newVal) {
		int location=0;
		for (int i=0; i<list.length; i++) {
			if (list[i] == newVal) {
				location = i;}
		}
		if (location==0)
			return;
		else{
			for (int i = location; i<list.length;i++){
				if (i==list.length-1)
					list[i]=0;
				else list[i]=list[i+1];
			}
			used--;}
	}
	/**
	 * Sorts the array in descending order
	 */
	public void selectionSort(){
		for (int w=0;w<list.length;w++){
			for (int i=0;i<list.length;i++){
				if (list[i]<list[w]){
					temp = new int[list.length];
					temp[i]=list[w];
					list[w]=list[i];
					list[i]=temp[i];
				}
			}	
		}
	}
	/**
	 * Creates an array based on input values.
	 */
	public void read(){
		for (int i = 0; i < list.length; i++){
			System.out.print("Enter next number: ");
			list[i] = kb.nextInt();}
		used = list.length;
	}
	
	/**
	 * Return a string representing the list
	 * 
	 * @return a string representing the list
	 */

	public String toString() {
		String result = "";
		for (int i = 0; i < list.length; i++)
			result = result + i + ":\t" + list[i] + "\n";
		return result;
	}

	/**
	 * Return the index of the first occurrence of target in the list.
	 * 
	 * @param target
	 *            the value to search for
	 * @return -1 if target does not appear in the list
	 */

	public int search(int target) {
		for (int i = 0; i < list.length; i++)
			if (list[i] == target)
				return i;
		return -1;
	}

}
