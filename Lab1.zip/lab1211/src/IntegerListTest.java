
/**
 * IntegerListTest.java
 *
 * Provide a menu-driven tester for the IntegerList class.
 *         
 */

import java.util.Scanner;
public class IntegerListTest {

	private static IntegerList list = new IntegerList(10);
	private static Scanner keyboard = new Scanner (System.in);

    /**
     * Create a list, then repeatedly print the menu and do what the
     * user asks until they quit
     */
	
    public static void main(String[] args) 
    {
    	printHeading();
    	printMenu();
    	int choice = keyboard.nextInt();
    	while (choice != 0)
	    {
    		dispatch(choice);
    		printMenu();
    		choice = keyboard.nextInt();

	    }
    }


    /**
     * Do what the menu item calls for
     *
     * @param choice 
     */
    
    public static void dispatch(int choice)
    {
    	switch(choice)
	    {
	    	case 0: 
	    			System.out.println("Bye!");
	    			break;
	    	case 1:
	    			System.out.print("How big should the list be?");
	    			list = new IntegerList(keyboard.nextInt());
	    			list.randomize();
	    			break;
	    	case 2:
	    			System.out.print("Enter the value to look for: ");
	    			int loc = list.search(keyboard.nextInt());
	    			if (loc != -1)
	    				System.out.println("Found at location " + loc);
	    			else
	    				System.out.println("Not in list");
	    			break;
	    	case 3:
	    			System.out.println(list);
	    			break;
	    	case 4: System.out.print("Enter the value to add: ");
	    			list.addElement(keyboard.nextInt());
	    			break;
	    	case 5: System.out.print("Enter the value to remove: ");
	    			list.removeLast(keyboard.nextInt());
	    			break;
	    	case 6: list.selectionSort();
	    			break;
	    	case 7: IntegerList copyList=new IntegerList(list);
	    			break;
	    	case 8: System.out.print("How big should the list be?");
					list = new IntegerList(keyboard.nextInt());
					list.read();
					break;
	    	default:
	    			System.out.println("Sorry, invalid choice");
	    }
    }


    /**
     * Print the user's choices
     */
    
    public static void printMenu()
    {
    	System.out.println("\n   Menu   ");
    	System.out.println("   ====");
    	System.out.println("0: Quit");
    	System.out.println("1: Create a new list (** do this first!! **)");
    	System.out.println("2: Find an element in the list using sequential search");
    	System.out.println("3: Print the list");
    	System.out.println("4: Add an element to the list");
    	System.out.println("5: Remove an element from the list");
    	System.out.println("6: Sort the list in descending order");
    	System.out.println("7: Create a copy constructor");
    	System.out.println("8: Create a list through input");
    	System.out.print("\nEnter your choice: ");
    }
    
    /**
     * Print output heading
     */
    
    public static void printHeading()
    {
    	System.out.println ("Programmer: Nathan Kane");
    	System.out.println ("Course:     COSC 211, Fall 15");
    	System.out.println ("lab#:       1");
    	System.out.println ("Due date:   9-17-15\n");
    }
}
//Menu   
//====
//0: Quit
//1: Create a new list (** do this first!! **)
//2: Find an element in the list using sequential search
//3: Print the list
//4: Add an element to the list
//5: Remove an element from the list
//6: Sort the list in descending order
//7: Create a copy constructor
//8: Create a list through input

//Enter your choice: 1
//How big should the list be?10

//Enter your choice: 2
//Enter the value to look for: 12
//Not in list

//Enter your choice: 3
//0:	19
//1:	7
//2:	17
//3:	15
//4:	20
//5:	5
//6:	16
//7:	19
//8:	1
//9:	16

//Enter your choice: 4
//Enter the value to add: 5

//Enter your choice: 5
//Enter the value to remove: 16

//Enter your choice: 6

//Enter your choice: 7

//Enter your choice: 8
//How big should the list be?5
//Enter next number: 12
//Enter next number: 11
//Enter next number: 15
//Enter next number: 56
//Enter next number: 1

//Enter your choice: 0